package com.gsitm.intern.test.mybatis;

import lombok.Data;

/**
 * Description :
 *
 * @author leejinho
 * @version 1.0
 */

@Data
public class MyBatisTestDto {
    private String id;
    private String email;
}
