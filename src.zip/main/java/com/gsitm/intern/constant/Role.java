package com.gsitm.intern.constant;

public enum Role {
    USER, ADMIN
}
