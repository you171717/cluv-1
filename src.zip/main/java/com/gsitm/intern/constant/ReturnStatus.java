package com.gsitm.intern.constant;

public enum ReturnStatus {
    Y,
    N
}
