package com.gsitm.intern.constant;

public enum OrderStatus {
    ORDER, CANCEL, RETURN
}
