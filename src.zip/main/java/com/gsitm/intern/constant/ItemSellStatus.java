package com.gsitm.intern.constant;
public enum ItemSellStatus {
    SELL, SOLD_OUT
}