INSERT INTO `mybatis` (`id`, `email`)
VALUES (1, 'mybatis@gsitm.com');

INSERT INTO `mybatis2` (`id`, `email`)
VALUES (1, 'mybatis@gsitm.com');
