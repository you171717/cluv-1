DROP TABLE IF EXISTS mybatis;
DROP TABLE IF EXISTS mybatis2;

CREATE TABLE mybatis
(
    id    INT PRIMARY KEY,
    email VARCHAR(100)
);

CREATE TABLE mybatis2
(
    id    INT PRIMARY KEY,
    email VARCHAR(100)
);


